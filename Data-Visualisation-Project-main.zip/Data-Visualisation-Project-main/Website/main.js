import { loadData } from "./loaddata.js";
import { drawChart2 } from "./chart2.js";

const data = await loadData();

console.log("Main got:", data);

drawChart2();
