export async function drawChart2()
{
    console.log("Chart 2 starting...");

    // Load the mortality data
    const data = await d3.csv("../health_master_totals.csv");

    console.log("Chart 2 data loaded:", data);
    console.log("Number of rows:", data.length);

    // Convert year and value to numbers
    data.forEach(function(d)
    {
        d.year = +d.year;
        d.value = +d.value;
    });

    // Get the chart container
    const container = d3.select("#chart2");

    // Create the SVG
    const width = 900;
    const height = 500;

    const radius = 200;

    const svg = container
        .append("svg")
        .attr("width", width)
        .attr("height", height);

    // Create the chart group
    const chart = svg
        .append("g")
        .attr(
            "transform",
            "translate(" +
            width / 2 +
            "," +
            height / 2 +
            ")"
        );

    // Get the existing controls
    const countrySelect = d3.select("#country-select-2");
    const yearSlider = d3.select("#year-slider-2");
    const yearValue = d3.select("#year-value-2");

    // Create the pie layout
    const pie = d3.pie()
        .value(function(d)
        {
            return d.value;
        })
        .sort(null);

    // Create the arc
    const arc = d3.arc()
        .innerRadius(0)
        .outerRadius(radius);

    const colour = d3.scaleOrdinal(d3.schemeCategory10);    

    const tooltip = container
        .append("div")
        .attr("class", "chart2-tooltip")
        .style("position", "fixed")
        .style("visibility", "hidden")
        .style("background", "white")
        .style("border", "1px solid #999")
        .style("padding", "8px")
        .style("border-radius", "4px")
        .style("pointer-events", "none")
        .style("z-index", "1000");

    function updateChart()
    {
        // Get the selected country
        const selectedCountry = countrySelect.property("value");

        // Get the selected year
        const selectedYear = +yearSlider.property("value");
        yearValue.text(selectedYear);

        console.log(
            "Chart 2 updating:",
            selectedCountry,
            selectedYear
        );


        // Filter the data
        const filteredData = data.filter(function(d)
        {
            return d.country == selectedCountry
                && d.year == selectedYear
                && d.sex == "Total"
                && d.measure == "Mortality"
                && d.method == "Standardised rate"
                && d.category != "Total";
        });


        console.log(
            "Filtered Chart 2 data:",
            filteredData
        );

        // Sort from largest to smallest
        filteredData.sort(function(a, b)
        {
            return b.value - a.value;
        });

        const totalValue = d3.sum(
            filteredData,
            function(d)
            {
                return d.value;
            }
        );

        // Keep the eight largest causes
        const chartData = filteredData.slice(0, 8);


        // Add the remaining causes together
        const otherValue = d3.sum(
            filteredData.slice(8),
            function(d)
            {
                return d.value;
            }
        );


        if (otherValue > 0)
        {
            chartData.push({
                category: "Other",
                value: otherValue
            });
        }


        console.log(
            "Chart 2 final data:",
            chartData
        );


        // Create pie data
        const pieData = pie(chartData);


        // Create the slices
        const slices = chart
            .selectAll(".slice")
            .data(pieData);


        // Add the slices
        slices.enter()
            .append("path")
            .attr("class", "slice")
            .attr("stroke", "white")
            .attr("stroke-width", 2)
            .on("mouseover", function(event, d)
            {
                const percentage =
                    (d.data.value / totalValue) * 100;

                tooltip
                    .style("visibility", "visible")
                    .html(
                        "<strong>" +
                        d.data.category +
                        "</strong><br>" +
                        "Mortality rate: " +
                        d.data.value.toFixed(1) +
                        " per 100,000<br>" +
                        "Share: " +
                        percentage.toFixed(1) +
                        "%"
                    );
            })
            .on("mousemove", function(event)
            {
                tooltip
                    .style("top", (event.clientY + 10) + "px")
                    .style("left", (event.clientX + 10) + "px");
            })
            .on("mouseout", function()
            {
                tooltip
                    .style("visibility", "hidden");
            })
            .merge(slices)
            .transition()
            .duration(500)
            .attr("d", arc)
            .attr("fill", function(d)
            {
                return colour(d.data.category);
            });


        // Remove old slices
        slices.exit()
            .remove();


        // Add title
        svg
            .selectAll(".chart2-title")
            .remove();

        svg
            .append("text")
            .attr("class", "chart2-title")
            .attr("x", width / 2)
            .attr("y", 25)
            .attr("text-anchor", "middle")
            .style("font-size", "18px")
            .style("font-weight", "bold")
            .text(
                selectedCountry +
                " mortality by cause, " +
                selectedYear
            );
    }


    // Update when country changes
    countrySelect.on("change", function()
    {
        updateChart();
    });


    // Update when year changes
    yearSlider.on("input", function()
    {
        updateChart();
    });


    // Draw the chart
    updateChart();
}